package POO;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        //Introducimos los datos
        System.out.println("Introduce el nombre");
        String nombre = entrada.next();

        System.out.println("Introduce la edad");
        int edad = entrada.nextInt();

        System.out.println("Introduce el sexo");
        char sexo = entrada.next().charAt(0);

        System.out.println("Introduce el peso");
        double peso = entrada.nextDouble();

        System.out.println("Introduce la altura");
        double altura = entrada.nextDouble();
        
        Persona persona1 = new Persona(nombre, edad, sexo, peso, altura);
        System.out.println("Persona");
        MuestraMensajePeso(persona1);
        MuestraMayorDeEdad(persona1);
        System.out.println(persona1.toString());

    }

    public static void MuestraMensajePeso(Persona p) {
        int IMC = p.calcularIMC();
        switch (IMC) {
            case Persona.PESO_IDEAL:
                System.out.println("La persona esta en su peso ideal");
                break;
            case Persona.INFRAPESO:
                System.out.println("La persona esta por debajo de su peso ideal");
                break;
            case Persona.SOBREPESO:
                System.out.println("La persona esta por encima de su peso ideal");
                break;
        }
    }

    public static void MuestraMayorDeEdad(Persona p) {

        if (p.esMayorDeEdad()) {
            System.out.println("La persona es mayor de edad");
        } else {
            System.out.println("La persona no es mayor de edad");
        }
    }
}
