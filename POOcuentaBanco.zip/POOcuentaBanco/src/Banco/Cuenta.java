
package Banco;

public class Cuenta {
    
    private String cliente;
    private int  cuenta;
    private double interes;
    private double saldo;
    
    public Cuenta(String cliente, int cuenta,double interes, double saldo){
        this.cliente= cliente;
        this.cuenta= cuenta;
        this.interes= interes;
        this.saldo= saldo;
    
    }
    //__________________________________________________________________________
    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public double getInteres() {
        return interes;
    }

    public void setInteres(double interes) {
        this.interes = interes;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    //Ingreso___________________________________________________________________
    
    public boolean ingreso(double n) {
        boolean ingresoCorrecto = true;
        if (n < 0) {
            ingresoCorrecto = false;
        } else {
            saldo = saldo + n;
        }
        return ingresoCorrecto;
    }
   //Retiro_____________________________________________________________________
    public boolean  retiro(double n){
         boolean reintegroCorrecto = true;                                                                         
        if (n < 0) {
            reintegroCorrecto = false;
        } else if (saldo >= n) {
            saldo -= n;
        } else {
            reintegroCorrecto = false;
        }
        return reintegroCorrecto;
 
    }
    //Trasferencia______________________________________________________________
    public void transferencias(){
        
        
    }
    //__________________________________________________________________________
    
    public String mostrarDatos(){
        return "____________Cuenta___________" 
              +"\n cliente: " + cliente 
              +"\n cuenta: " + cuenta 
              +"\n interes: " + interes 
              +"\n saldo: " + saldo  
              +"\n____________________________";
    //__________________________________________________________________________
        
    }
}
