package Banco;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static ArrayList<Cuenta> clientes = new ArrayList<Cuenta>();
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        int opc;
        do {

            System.out.println(" ____________MENU_____________");
            System.out.println("|         Banco '  '          |");
            System.out.println("|    1. Crear una Cuenta      |");
            System.out.println("|    2. Mostrar Cuentas       |");
            System.out.println("|         3. Salir            |");
            System.out.println("|_____________________________|");

            opc = entrada.nextInt();
            switch (opc) {
                case 1:
                    llenarCuenta();
                    break;
                case 2:
                    mostrarDatos();
                    break;
                default:
                    break;
            }
        } while (opc != 3);

    }

    public static void llenarCuenta() {

        String cliente;
        int cuenta, opc;
        double interes, saldo, nuevoDato;

        System.out.println("Nombre: ");
        entrada.nextLine();
        cliente = entrada.nextLine();
        System.out.println("Numero de cuenta: ");
        cuenta = entrada.nextInt();
        System.out.println("Tipo de interes: ");
        interes = entrada.nextDouble();
        System.out.println("saldo nuevo : ");
        saldo = entrada.nextDouble();

        Cuenta cliente1 = new Cuenta(cliente, cuenta, interes, saldo);
        clientes.add(cliente1);

        do {

            System.out.println("**********Elige un Opccion*********");
            System.out.println("*   1. ingresar un nuevo saldo    *");
            System.out.println("*   2. Retirar un nuevo saldo     *");
            System.out.println("*   3. informacion de la cuenta   *");
            System.out.println("*           4. Salir              *");
            System.out.println("***********************************");

            opc = entrada.nextInt();
            switch (opc) {
                case 1:
                    System.out.println("Digite el nuevo saldo a Ingresar");
                    cliente1.ingreso(nuevoDato = entrada.nextDouble());
                    break;
                case 2:
                    System.out.println("Digite el saldo que desea Retirar");
                    cliente1.retiro(nuevoDato = entrada.nextDouble());
                    break;
                case 3:
                    System.out.println(cliente1.mostrarDatos());
                    break;
                default:
                    break;
            }
        } while (opc != 4);

    }

    public static void mostrarDatos() {

        for (Cuenta clien : clientes) {
            System.out.println(clien.mostrarDatos());
        }
    }
    
}
