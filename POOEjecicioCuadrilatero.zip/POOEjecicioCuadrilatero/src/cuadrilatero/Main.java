package cuadrilatero;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        Cuadrilatero entrada;
        float lado1, lado2;

        lado1 = Float.parseFloat(JOptionPane.showInputDialog("Digiite el lado uno"));
        lado2 = Float.parseFloat(JOptionPane.showInputDialog("Digiite el lado uno"));

        if (lado1 == lado2) {
            entrada = new Cuadrilatero(lado1);

        } else {
            entrada=new Cuadrilatero(lado1,lado2);

        }
        System.out.println("el perimetro es : "+entrada.getPerimetro());
        System.out.println("el area es : "+entrada.getArea());
    }
}
