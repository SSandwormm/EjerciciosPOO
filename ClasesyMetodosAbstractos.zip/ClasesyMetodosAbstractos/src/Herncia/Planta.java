package Herncia;


//ya sabe como se limeta una planta 
public class Planta extends SerVivo {

    @Override
    public  void alimentarse() {
        System.out.println("la planta se alimenta a traves de la fotosintesis ");
    }
}
