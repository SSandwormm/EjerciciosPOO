package Herncia;

/*necesitas que este aca pero no sabe como se limentan lo seres vivos
  y animales se alimentas pero necesita mas especificaciones 
por eso nace dos clases hijas  Animal Herbivoro y Animal Carnivoro*/
public abstract class Animal extends SerVivo {

   

}
