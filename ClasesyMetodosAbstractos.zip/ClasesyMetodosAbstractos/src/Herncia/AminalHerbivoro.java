
package Herncia;

//ya sabe como se alimenta un animal herbivoro
public class AminalHerbivoro extends Animal{
    
    @Override
    public void alimentarse(){
        System.out.println("el animal herbivoro se alimenta de hierbas");
    }
}
