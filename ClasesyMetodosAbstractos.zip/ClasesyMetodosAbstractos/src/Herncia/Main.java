
package Herncia;

public class Main {
    public static void main(String[] args) {
        Planta planta =new Planta();
        AnimalCarnivoro animalc=new AnimalCarnivoro();
        
        animalc.alimentarse();
        planta.alimentarse();
        
        
        //no sirve por que es abstract
//        SerVivo servivo =new SerVivo();
//        servivo.alimentarse();
        
    }
}
