
package Herncia;

//se utiliza como super claase
//no se puede instanciar objetosa 
/*sirve para prporcionar una super clase 
apropiada apartir de la ual hereda otras clase*/

/*necesitas que este aca pero no sabe como se limentan lo seres vivos
  necesita mas especificaciones, pero sabes que los seres vivos se alimentan*/
public abstract class SerVivo {
    
    public abstract void alimentarse();
        
    
}
