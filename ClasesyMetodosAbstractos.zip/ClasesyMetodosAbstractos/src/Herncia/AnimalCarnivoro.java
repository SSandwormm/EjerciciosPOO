
package Herncia;

//ya sabe como se alimenta un animal carnivoro
public class AnimalCarnivoro extends Animal{
    
    @Override
    public void alimentarse(){
        System.out.println("el animal canivoro se alimenta de carne");
    }
}
