package Herencia;

public class Main {

    public static void main(String[] args) {
         //crear objeto y llamar metodo
        Estudiante estudiantes1 = new Estudiante("SSand","Wormm",21,23,07);
        estudiantes1.mostrarDatos();

    }

}
