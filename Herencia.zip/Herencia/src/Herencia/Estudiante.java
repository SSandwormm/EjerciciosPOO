package Herencia;

public class Estudiante extends Persona {

    // atributos unicos del estudiantes 
    private int codigoEstudiante;
    private float notaFinal;

    // contructor con parametros de persona  mas los unicos de estudiantes 
    public Estudiante(String nombre, String apellido, int edad, int codigoEstudiante, float notaFinal) {
        //palabra super sirve para  cuales atributos estan inicialisados o son herredadosde otra clase
        super(nombre, apellido, edad);
        this.codigoEstudiante = codigoEstudiante;
        this.notaFinal = notaFinal;
    }

    //metodo
    public void mostrarDatos() {
        System.out.println(" nombre: " + getNombre()
                + "\n apellido: " + getApellido()
                + "\n edada: " + getEdad()
                + "\n Codigo Estudiante: " + codigoEstudiante
                + "\n Nota Final: " + notaFinal);
    }

}
