
package Pista;

import java.util.Scanner;

public class Main {
    
    /*no se deje confundir cuando dice el mas ganador  puede se el que
    mas tiempo hizo o menos tiempo hizo */
    
    public static int atletaRapido(Atleta corredores[]) {
        float tiempo;
        int indice =0;

        tiempo = corredores[indice].getTiempo();
        for (int i = 0; i < corredores.length; i++) {
            if (corredores[i].getTiempo() < tiempo) {
                tiempo= corredores[i].getTiempo();
                indice = i;
            }
        }
        return indice;
    }
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);   
        int numero;
        String nombre;
        float tiempo;
        int cantidad;
        int indiceTiempo;
        
        System.out.println("Cantidad de Atletas participantes :");
        cantidad = entrada.nextInt();
        
         Atleta corredores[] = new Atleta[cantidad];
         
         for (int i = 0; i < corredores.length; i++) {
            
            System.out.println("digite las caracteristicas del Atleta " + (i + 1) + ":");
            entrada.nextLine();
            System.out.print("Numero :");
            numero = entrada.nextInt();
            entrada.nextLine();
            System.out.print("nombre :");
            nombre = entrada.nextLine();
            System.out.print("tiempo :");
            tiempo = entrada.nextFloat();

            corredores[i] = new Atleta(numero, nombre, tiempo);

        }
              indiceTiempo = atletaRapido (corredores);
        System.out.println("\n El corredor con mejor tiempo es :"
        + "\n"+(corredores[indiceTiempo].mostrarGanador()));
    }
}
