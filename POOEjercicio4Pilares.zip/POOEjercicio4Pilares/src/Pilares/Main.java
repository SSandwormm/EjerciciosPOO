package Pilares;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static ArrayList<Poligono> poligono = new ArrayList<Poligono>();
//    Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("");
        llenarPoligono();
        
        mostarDatos();
        
    }

    public static void llenarPoligono() {
        Scanner entrada =new Scanner (System.in);
        int opc;
        char respuesta;
        do {
            do {
                System.out.println("que póligono desea?");
                System.out.println("1. triangulo");
                System.out.println("2. rectangulo");
                System.out.println("");
                opc = entrada.nextInt();

            } while (opc < 1 || opc > 2);
            switch (opc) {
                case 1:
                    llenarTriangulo();

                    break;
                case 2:
                    llenarRectangulo();

                    break;
                default:

            }
            System.out.println(" desea introducir otro poligono ()s/n");
            respuesta = entrada.next().charAt(0);
        } while (respuesta == 's'|| respuesta == 'S');
    }
    
    public static void llenarTriangulo(){
        Scanner entrada= new Scanner(System.in);
     double lado1,lado2,lado3;
     
        System.out.println("digite el lado 1");
        lado1=entrada.nextDouble();
        System.out.println("digite el lado 2");
        lado2=entrada.nextDouble();
        System.out.println("digite el lado 3");
        lado3=entrada.nextDouble();
        
        Triangulo triangulo =new  Triangulo(lado1,lado2, lado3);
        
        poligono.add(triangulo); 
        
    }
    
    public static void llenarRectangulo (){
    
        Scanner entrada=new Scanner(System.in);
        double lado1,lado2;
        
        System.out.println("digite el lado 1");
        lado1=entrada.nextInt();
        System.out.println("digite el lado 2");
        lado2=entrada.nextInt();
        
        Rectangulo rectangulo =new Rectangulo(lado1, lado2);
        
        poligono.add(rectangulo);
        
    
    }
    
    public static  void mostarDatos(){
        
        for (Poligono poli : poligono) {
            System.out.println(poli.toString());
            System.out.println("area : "+poli.area());
        }
    
    }
}
