
package Pilares;


public class Triangulo extends Poligono{
    private double lados1;
    private double lados2;
    private double lados3;

    public Triangulo(double lados1, double lados2, double lados3) {
        super(3);
        this.lados1 = lados1;
        this.lados2 = lados2;
        this.lados3 = lados3;
    }

    public double getLados1() {
        return lados1;
    }

    public double getLados2() {
        return lados2;
    }

    public double getLados3() {
        return lados3;
    }

    @Override
    public String toString() {
        return "\nTriangulo{" +super.mostrarDatos()+ ", lados1=" + lados1 + ", lados2=" + lados2 + ", lados3=" + lados3 + '}';
    }
    
    @Override
    public double area(){
     double p=(lados1+lados2+lados3)/2;
     return Math.sqrt((p*(p-lados1)*(p-lados2)*(p-lados3)));
    }
    
}
