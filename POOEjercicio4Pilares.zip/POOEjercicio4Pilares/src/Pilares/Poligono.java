package Pilares;

public abstract class Poligono {

    protected int numerosLados;

    public Poligono(int numeroLados) {
        this.numerosLados = numeroLados;
    }
    public int getnumeroLados(){
        return numerosLados;
    }

    public String mostrarDatos() {
        return "Poligono :" + "numerosLados=" + numerosLados ;
    }
    
    public  abstract double area ();
}
   

