
package paquete1;


public class Clase2 {
    
    public static void main(String[] args) {
        Clase1 objeto1=new Clase1();
        
        objeto1.setEdad(23);
        System.out.println("la edad es "+objeto1.getEdad());
        
        objeto1.setNombre("Carlos");
        System.out.println("el nombre es "+objeto1.getNombre());
          
    }
}
