package Herencia;

public class Persona extends Comer {

    //overider significa que estamos sobre escribiendo el metodo comer
    // overider nos ayudar a sobre ecribir si oculta  el metodo comer del Persona -
    // parasaria escribir los que esta heredando de la clase principal comer
    @Override
    public void comerr() {
        System.out.println("estoy comiendo sentado y con cubiertos");
    }
    
    //ocultela y mira
//    public void comerr() {
//        System.out.println("estoy comiendo sentado y con cubiertos");
//    }
}
