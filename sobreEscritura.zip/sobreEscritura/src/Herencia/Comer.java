
package Herencia;

// clase comer, metodo comer. todos comen !
// un animal come  diferente a una persona  
public class Comer {
    
     public void comerr(){
         
        System.out.println("estoy comiendo");
    }
    
}
