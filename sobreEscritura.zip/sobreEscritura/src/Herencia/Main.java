package Herencia;

public class Main {

    public static void main(String[] args) {
        Persona persona1 = new Persona();
        Perro perro = new Perro();

        persona1.comerr();
        perro.comerr();
    }

}
