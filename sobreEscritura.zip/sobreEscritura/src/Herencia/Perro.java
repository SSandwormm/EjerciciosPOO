
package Herencia;


public class Perro extends Comer {
    
    //lo vuelvo a sobre escribir 
    
    @Override
    public void comerr(){
        System.out.println("estoy comiendo con mi plato en el suelo");
    }
    
}
