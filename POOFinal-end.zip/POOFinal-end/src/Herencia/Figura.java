
package Herencia;


public class Figura {
    private double tamaño;
    
    public Figura(double tamaño){
     this.tamaño=tamaño;
    }
}
