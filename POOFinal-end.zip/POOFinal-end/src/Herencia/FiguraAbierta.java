
package Herencia;


public class FiguraAbierta {
    
}
