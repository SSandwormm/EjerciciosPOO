
package Herencia;


public class Main {
    public static void main(String[] args) {
        FCCuadrado cuadrado =new FCCuadrado(15,4,10);
        cuadrado.dibujar();
    }
}
