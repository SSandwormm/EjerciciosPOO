
package Herencia;

// final en esta clase no deja crear  FCCuadrado 
// final en una clase se pone al antes del public 
/*final*/ public class FiguraCerrada extends Figura{
    private int lados ;
    
    public FiguraCerrada(int tamaño,int lados){
         super(tamaño);
         this.lados=lados;
    }
    //final en metodo se pene despues del public 
    public /*final*/   void dibujar(){
        System.out.println(" dibujar una figura cerrada");
    }
}
