
package Herencia;

// final significa cancelar y no tener mas hijos en las clases
//final
public class FCCuadrado extends FiguraCerrada{
    private double area;
    
    public FCCuadrado (int tamaño, int lados, double area){
        super(tamaño, lados);
        this.area=area;
    }
    
    
    //error final si tiene el mismo nombre  da error
    public void dibujar(){
        System.out.println("dibujar cuadrado");
    }
}
