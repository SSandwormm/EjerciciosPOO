package ClasesYObjetos;

public class Vehiculo {

    //Atributos
    String color;
    String marca;
    int km;

    //Metodos 
    public static void main(String[] args) {
        //Objetos
        Vehiculo coche1 = new Vehiculo();
        //Atributos  
        coche1.color = "Rojo";
        coche1.marca = "Audi";
        coche1.km = 0;

        System.out.println("color  carro " + coche1.color);
        System.out.println("kilometraje carro " + coche1.km);
        System.out.println("marca carro " + coche1.marca);

        //Objeto
        Vehiculo moto1 = new Vehiculo();
        
        //Atributos
        moto1.color = "Rojo";
        moto1.marca = "Audi";
        moto1.km = 500;
        
        System.out.println("\ncolor moto " + moto1.color);
        System.out.println("kilometraje moto " + moto1.km);
        System.out.println("marca  moto " + moto1.marca);

    }

}
