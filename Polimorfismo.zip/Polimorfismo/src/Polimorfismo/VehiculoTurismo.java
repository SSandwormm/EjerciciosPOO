
package Polimorfismo;


public class VehiculoTurismo extends Vehiculo{
    private int numPuertas;
    
    public VehiculoTurismo (String matricula, String marca, String modelo, int numPuertas){
        super(matricula, marca, modelo);
        this.numPuertas=numPuertas;
      
    }

    public int getNumPuertas() {
        return numPuertas;
    }

    
    @Override
    public String mostrarDatos() {
        return  "matricula=" + matricula + ", marca=" + marca + ", modelo=" + modelo + ", numPuertas=" + numPuertas ;
    }
    
    
    
}
