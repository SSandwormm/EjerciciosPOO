
package Polimorfismo;

public class Main {
    
    public static void main(String[] args) {
        Vehiculo misvehiculos []=new Vehiculo[3];
        
        misvehiculos[0]=new Vehiculo ("Z4","Ferrari","aas545");
        misvehiculos[1]=new VehiculoTurismo("s","audi","sda645",5);
        misvehiculos[2]=new VehiculoDeportivo(500,"rz","BMW","kjg654");
        
        for (Vehiculo vehiculo : misvehiculos) {
            System.out.println(vehiculo.mostrarDatos());
            System.out.println("");
        }
        
    }
}
