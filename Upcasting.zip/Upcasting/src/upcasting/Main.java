
package upcasting;

public class Main {
    
    public static void main(String[] args) {
        //upcasting
        //tomar un objeto se la subclase y convertirlo en la super clase 
//_______________________________________________________________     
//        Vehiculo vehiculo=new VehiculoTurismo("prado","toyota","ghd654",6);
//        System.out.println(vehiculo);
        
        
        //downcasting
//________________________________________________________________        
        Vehiculo vehiculo=new VehiculoDeportivo(500,"phanton","Ferrari","ghd654");
        VehiculoDeportivo nuevoVehiculo =(VehiculoDeportivo)vehiculo;
        System.out.println(nuevoVehiculo);
    }
}
