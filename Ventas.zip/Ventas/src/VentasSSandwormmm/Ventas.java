
package VentasSSandwormmm;

import ventasSSandwormm.Orden;
import ventasSSandwormm.Producto;

public class Ventas {
    public static void main(String[] args) {
        
         Producto producto1 =new Producto("camisa", 50.000);
         Producto producto2 =new Producto("Pantalon", 70.000);
         Producto producto3 =new Producto("medias", 6.000);
         
         Orden orden1 = new Orden();
         orden1.agregarProducto(producto1);
         orden1.agregarProducto(producto2);
         orden1.agregarProducto(producto3);
         orden1.mostarOrden();
         
    }
}
