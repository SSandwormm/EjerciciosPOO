package movimiento;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Movimiento movi1;
        int x, y;
        int opc;
        int incremento = 0;

        System.out.println("digite la cordenada inicial de X:");
        x = entrada.nextInt();
        System.out.println("digite la cordenada inicial de Y:");
        y = entrada.nextInt();

        movi1 = new Movimiento(x, y);
        do {
            System.out.println("\n Menu"
                    + "\n 1. Mover ARRIBA "
                    + "\n 2. Mover ABAJO"
                    + "\n 3. Mover DERECHA"
                    + "\n 4. Mover IZQUIERDA"
                    + "\n 5. Salir");
            opc = entrada.nextInt();

            if (opc != 5) {
                System.out.println("digite cantidad de espacios amoverse");
                incremento = entrada.nextInt();
            }

            switch (opc) {
                case 1:
                    movi1.moverArriba(incremento);
                    break;
                case 2:
                    movi1.moverAbajo(incremento);
                    break;
                case 3:
                    movi1.moverDrecha(incremento);
                    break;
                case 4:
                    movi1.moverIzquierda(incremento);
                    break;
                default:
                    System.out.println("error, Numero invalido");
                    break;
            }
            System.out.println(" Posicion Actual "+movi1.getX()+" "+","+" "+movi1.getY());
        } while (opc != 5);
    }
}
