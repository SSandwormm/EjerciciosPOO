package vehiculo;

import java.util.Scanner;

public class Main {

     public static int autoEconomico(Vehiculo autos[]) {
        float precio;
        int indice =0;

        precio = autos[0].getPrecio();
        for (int i = 0; i < autos.length; i++) {
            if (autos[i].getPrecio() < precio) {
                precio = autos[i].getPrecio();
                indice = i;
            }
        }
        return indice;
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String marca, modelo;
        float precio;
        int cantidad;
        int indiceEconomico;

        System.out.println("cantidad de vehiculos quiere incorporar :");
        cantidad = entrada.nextInt();

        Vehiculo autos[] = new Vehiculo[cantidad];

        for (int i = 0; i < autos.length; i++) {
            entrada.nextLine();
            System.out.println("digite las caracteristicas del auto " + (i + 1) + ":");
            System.out.print("marca :");
            marca = entrada.nextLine();
            System.out.print("modelo :");
            modelo = entrada.nextLine();
            System.out.print("precio :");
            precio = entrada.nextFloat();

            autos[i] = new Vehiculo(marca, modelo, precio);

        }
        indiceEconomico = autoEconomico (autos);
        System.out.println("\n El auto mas barato es:"
        + "\n"+(autos[indiceEconomico].mostrarDatos()));
    }
}
