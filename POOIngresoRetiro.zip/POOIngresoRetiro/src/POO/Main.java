package POO;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.println("titular");
        String nombre = entrada.next();

        System.out.println("cantidad");
        double cantidad = entrada.nextDouble();

        Cuenta cuenta1 = new Cuenta(nombre, cantidad);

        System.out.println("ingresa cantidad ");
        cantidad = entrada.nextDouble();
        cuenta1.ingresar(cantidad);

        System.out.println("retira cantidad ");
        cantidad = entrada.nextDouble();
        cuenta1.retirar(cantidad);

        System.out.println("cantidad total");
        System.out.println(cuenta1);

    }
}
