package Interfaces;

public class Main {

    public static void main(String[] args) {
        MusicoEstudiante musicoE = new MusicoEstudiante();

        musicoE.hablar();
        musicoE.estudiar();
        musicoE.tocarMusica();
    }

}
