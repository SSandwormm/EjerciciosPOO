
package Interfaces;

public class MusicoEstudiante implements Musico,Estudiante{
    
    public void hablar (){
        System.out.println(" estoy hablando español");
    }
    @Override
    public void tocarMusica(){
        System.out.println(" estoy tocando la guirttara ");
    }
    
    @Override
    public void estudiar (){
        System.out.println(" estoy estudiando ");
    } 
}
