
package Interfaces;


public interface Persona {
    
}
