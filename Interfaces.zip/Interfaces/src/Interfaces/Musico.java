
package Interfaces;

public interface Musico extends Persona{
    
    public abstract  void tocarMusica();
    
}
