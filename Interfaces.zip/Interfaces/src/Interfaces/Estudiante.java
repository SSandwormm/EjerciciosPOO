
package Interfaces;

public interface Estudiante extends Persona{
    
    public abstract void estudiar();
}
