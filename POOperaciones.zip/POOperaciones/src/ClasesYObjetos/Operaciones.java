
package ClasesYObjetos;

import javax.swing.JOptionPane;


public class Operaciones {
    int numero1;
    int numero2;
    int suma;
    int resta;
    int multiplicacion;
    int divicion;
    
    public void  LeerNumeros(){
        numero1=Integer.parseInt(JOptionPane.showInputDialog("numero 1"));
        numero2=Integer.parseInt(JOptionPane.showInputDialog("numero 2"));         
    }
    public void suma(){
        suma=numero1+numero2;
    }
    
    public void resta(){
         resta =numero1-numero2;
    }
    public  void multiplicacion(){
         multiplicacion=numero1*numero2;
    }
    
    public void divicion(){
          divicion=numero1/numero2;
    }
    public void Resultado(){
         System.out.println("la suma es  "+suma);
         System.out.println("la resta es "+resta);
         System.out.println("la multiplicacion es "+multiplicacion);
         System.out.println("la divicion es " + divicion);
         
    }
    
}
