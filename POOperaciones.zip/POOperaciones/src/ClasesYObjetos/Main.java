package ClasesYObjetos;

public class Main {

    public static void main(String[] args) {
        Operaciones Op = new Operaciones();

        Op.LeerNumeros();
        Op.suma();
        Op.resta();
        Op.multiplicacion();
        Op.divicion();
        Op.Resultado();
    }
}
