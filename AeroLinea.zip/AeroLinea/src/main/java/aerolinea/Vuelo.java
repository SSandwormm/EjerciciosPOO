
package aerolinea;

public class Vuelo {
    private int nuemero; 
    
    
}
