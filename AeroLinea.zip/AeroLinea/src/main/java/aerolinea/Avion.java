
package aerolinea;

public class Avion {
    private String compañia;
    private String tipo;
    private int nPasajeros;

    public Avion(String compañia, String tipo, int nPasajeros) {
        this.compañia = compañia;
        this.tipo = tipo;
        this.nPasajeros = nPasajeros;
    }
    
    
    
}
