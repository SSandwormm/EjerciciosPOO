package aerolinea;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

    static ArrayList<String> loginn = new ArrayList<>();
    static ArrayList<Reservar> reservarr = new ArrayList<>();
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
//        JOptionPane.showMessageDialog(null, " ");
//        String correo = JOptionPane.showInputDialog("");
//        

       int opc = Integer.parseInt(JOptionPane.showInputDialog( "Bienvenido a la Terminal Aerea"
                + "\n 1 Consulta de vuelos"
                + "\n 2 Reserva de vuelos"
                + "\n 3 Compara de billetes"
                + "\n 4 Login"
                + "\n 5 Registarse"
                + "\n 6 salir "));

        /* si no es registrado no puede reservar, consultar
        comprar*/
        switch (opc) {
            case 1:
                JOptionPane.showMessageDialog(null, " Consultar ");

                break;
            case 2:
                JOptionPane.showMessageDialog(null, " Resevar ");
                reservaVuelos();
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "Comprar ");

                break;
            case 4:
                System.out.println("Login");
                break;
            case 5:
                System.out.println("Registro");
                break;
        }
    }

    public static void consultaVuelos() {
        /*___consltar segun horario horarios de diferentes aerolineas
        que van entre ciudades 
        ___consulta segun tarifa muestra los vuelos entre dos 
        ciudades ordenados costo 
        ____informacion eatdo de un vuelo asientos disponible vuelos 
        al mismo dia  si éste está en hora. Se pueden incluir preferencias 
        en las búsquedas, como fecha y deseado, categoría de asiento, 
        aerolínea deseada y si se desean sólo vuelos directos */

    }

    public static void reservaVuelos() {
        /*reserva de vuelo permite al cliente hacer una reserva para un vuelo
        particular, especificando la fecha o, bajo una tarifa establecida. 
        Es posible reservar un itinerario compuesto de múltiplespara uno 
        o más pasajeros, además de poder reservar asientos*/

        String nombre_pasajero = JOptionPane.showInputDialog("Nombre del Pasajero");
        String direcion_pasajero = JOptionPane.showInputDialog("Direcion del Pasajero");
        String ciudad_pasajero = JOptionPane.showInputDialog("Ciudad del Pasajero");
        String pais_pasajero = JOptionPane.showInputDialog("Pais del Pasajero");
        String telefono_pasajero = JOptionPane.showInputDialog("Telefono del Pasajero");
        String email_pasajero = JOptionPane.showInputDialog("Email del Pasajero");
        int numero_tarjeta = Integer.parseInt(JOptionPane.showInputDialog("Numero de Tarjeta"));
        String tipo_tarjeta = JOptionPane.showInputDialog("Tipo de Tarjeta");;
        int clave =123;
        int claveU = Integer.parseInt(JOptionPane.showInputDialog("Ingresa clave"));
        if (claveU == clave) {
            double costo_total= Double.parseDouble(JOptionPane.showInputDialog("Costo total"));
           
              Reservar reservar = new Reservar(clave, nombre_pasajero, direcion_pasajero, ciudad_pasajero, 
                      pais_pasajero, telefono_pasajero, email_pasajero, numero_tarjeta, tipo_tarjeta);
              reservarr.add(reservar);
              
              reservar.mostarPasajeros();
              reservar.mostarTarjeta();
              reservar.mostarReserva();
              
              
            
        }else{
         JOptionPane.showMessageDialog(null, " No sirvio esta mierda");
        }
      
    }

    public static void compraVuelos() {
        /*a permite al cliente, dada una reserva de vuelo previa y una 
        tarjeta de crédito válida,los billetes aéreos. Los billetes 
        serán posteriormente enviados al cliente el usuario podrá en 
        cualquier momento leer, modificar o cancelar su propio registro,
        todo esto después de haber sido el usuario validado en el sistema.*/

    }

}
