
package aerolinea;

public class Dia {
    private String dia;
    private String hora;

    public Dia(String dia, String hora) {
        this.dia = dia;
        this.hora = hora;
    }
    
    
    
}
