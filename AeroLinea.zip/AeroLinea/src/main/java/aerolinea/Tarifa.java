
package aerolinea;

public class Tarifa {
    
    private String clase;
    private Double precio;
    private double impuesto;

    public Tarifa(String clase, Double precio, double impuesto) {
        this.clase = clase;
        this.precio = precio;
        this.impuesto = impuesto;
    }
    
    
}
