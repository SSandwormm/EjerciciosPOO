
package aerolinea;

public class Aerolinea extends Avion{
     private String nombre;

    public Aerolinea(String compañia, String tipo, int nPasajeros) {
        super(compañia, tipo, nPasajeros);
    }

    public Aerolinea(String nombre, String compañia, String tipo, int nPasajeros) {
        super(compañia, tipo, nPasajeros);
        this.nombre = nombre;
    }
     
     
}
