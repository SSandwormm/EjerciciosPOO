
package aerolinea;


public class Asiento {
    private String fila;
    private String letra;

    public Asiento(String fila, String letra) {
        this.fila = fila;
        this.letra = letra;
    }
    
    
}
