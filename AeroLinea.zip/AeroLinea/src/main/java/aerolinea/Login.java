package aerolinea;

public class Login {

    private String correo_usuario;
    private String contraseña;
    private String Arreglo[];

    public Login(String correo_usuario, String contraseña) {
        this.correo_usuario = correo_usuario;
        this.contraseña = contraseña;
    }


    public Login(String correo_usuario) {
        this.correo_usuario = correo_usuario;
        generarContraseña();
    }

    public Login(Login copia) {
      correo_usuario =copia.correo_usuario;
     contraseña =copia.contraseña;
    }

    public String getCorreo_usuario() {
        return correo_usuario;
    }

    public void setCorreo_usuario(String correo_usuario) {
        this.correo_usuario = correo_usuario;
    }

    
    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    
    
    private void generarContraseña() {
        final int divisor = 23;

        int numcontraseña = ((int) Math.floor(Math.random() * (1000 - 100) + 1000));
        int res = numcontraseña - (numcontraseña / divisor * divisor);

        char letramCont = generaLetrasmContraseña(res);
        char letraCont = generaLetrasContraseña(res);
        contraseña = letramCont + Integer.toString(numcontraseña) + letraCont + letramCont 
                + Integer.toString(numcontraseña) + letramCont + letraCont + letramCont;
    }

    private char generaLetrasContraseña(int res) {
        char letras[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
            'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
            'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

        return letras[res];
    }

    private char generaLetrasmContraseña(int ress) {
        char letrass[] = {'t', 'r', 'w', 'a', 'g', 'm', 'y',
            'f', 'p', 'd', 'x', 'b', 'n', 'j', 'z',
            's', 'q', 'v', 'h', 'l', 'c', 'k', 'e'};

        return letrass[ress];
    }

    public String mostrarDatos() {
        return "Nuevo Usuario"
                + "\ncorreo_usuario: " + correo_usuario
                + "\ncontraseña_usuario: " + contraseña;
    }

    
    public String mostrar() {
        return "\nLogin" 
                + "\nusuario=" + correo_usuario 
                + "\ncontraseña=" + contraseña ;
    }
    
    
}

// private String id ;
//     private String nombre;
//     private String apellido;
//     private String telefono;
//
//    public Usuario(String id, String nombre, String apellido, String telefono) {
//        this.id = id;
//        this.nombre = nombre;
//        this.apellido = apellido;
//        this.telefono = telefono;
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public String getNombre() {
//        return nombre;
//    }
//
//    public void setNombre(String nombre) {
//        this.nombre = nombre;
//    }
//
//    public String getApellido() {
//        return apellido;
//    }
//
//    public void setApellido(String apellido) {
//        this.apellido = apellido;
//    }
//
//    public String getTelefono() {
//        return telefono;
//    }
//
//    public void setTelefono(String telefono) {
//        this.telefono = telefono;
//    }
