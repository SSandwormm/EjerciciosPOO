
package aerolinea;


public class Pasajero extends Tarjeta{
    private String nombre_pasajero;
    private String direcion_pasajero;
    private String ciudad_pasajero;
    private String pais_pasajero;
    private String telefono_pasajero;
    private String email_pasajero;

    public Pasajero(String nombre_pasajero, String direcion_pasajero, String ciudad_pasajero, String pais_pasajero, String telefono_pasajero, String email_pasajero, int numero_tarjeta, String tipo_tarjeta) {
        super(numero_tarjeta, tipo_tarjeta);
        this.nombre_pasajero = nombre_pasajero;
        this.direcion_pasajero = direcion_pasajero;
        this.ciudad_pasajero = ciudad_pasajero;
        this.pais_pasajero = pais_pasajero;
        this.telefono_pasajero = telefono_pasajero;
        this.email_pasajero = email_pasajero;
    }

    public String mostarPasajeros() {
        return "Pasajero" 
                + "\nnombre_pasajero=" + nombre_pasajero 
                + "\ndirecion_pasajero=" + direcion_pasajero 
                + "\nciudad_pasajero=" + ciudad_pasajero 
                + "\npais_pasajero=" + pais_pasajero 
                + "\ntelefono_pasajero=" + telefono_pasajero 
                + "\nemail_pasajero=" + email_pasajero;
    }

   
    
    
    
}
