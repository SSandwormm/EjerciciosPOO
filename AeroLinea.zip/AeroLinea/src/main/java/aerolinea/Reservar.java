
package aerolinea;


public class Reservar extends Pasajero{
    private int clave;

    public Reservar(int clave, String nombre_pasajero, String direcion_pasajero, String ciudad_pasajero, String pais_pasajero, String telefono_pasajero, String email_pasajero, int numero_tarjeta, String tipo_tarjeta) {
        super(nombre_pasajero, direcion_pasajero, ciudad_pasajero, pais_pasajero, telefono_pasajero, email_pasajero, numero_tarjeta, tipo_tarjeta);
        this.clave = clave;
    }
    
    
    
    public String mostarReserva() {
        return  "\nclave=" + clave;
    }

 
    
    
    
}
