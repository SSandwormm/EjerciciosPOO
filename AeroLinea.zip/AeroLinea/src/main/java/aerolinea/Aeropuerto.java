
package aerolinea;

public class Aeropuerto {
    
    private String nombre;
    private String ciudad;
    private String pais;

    public Aeropuerto(String nombre, String ciudad, String pais) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.pais = pais;
    }
    
    
}
