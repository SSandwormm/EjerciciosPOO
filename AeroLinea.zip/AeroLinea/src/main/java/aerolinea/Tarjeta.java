
package aerolinea;

public class Tarjeta {
    
    
    private int numero_tarjeta;
    private String tipo_tarjeta;

    public Tarjeta(int numero_tarjeta, String tipo_tarjeta) {
        this.numero_tarjeta = numero_tarjeta;
        this.tipo_tarjeta = tipo_tarjeta;
    }

  

    
    public String mostarTarjeta() {
        return  "\nnumero_tarjeta=" + numero_tarjeta 
                + "\ntipo_tarjeta=" + tipo_tarjeta ;
    }

    
    
}
